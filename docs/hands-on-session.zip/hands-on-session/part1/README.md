This is sligtly modified version of code available at https://github.com/dennybritz/nn-from-scratch

